<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

    <style type = text/css>
      /*==================== 
        Footer 
    ====================== */
    @import url('https://fonts.googleapis.com/css?family=Acme|Handlee|Bitter|Odibee+Sans|Simonetta|Trade+Winds&display=swap');
    /* Main Footer */
    footer .main-footer{font-family: 'Acme';box-shadow: -3px -3px 5px black;	padding: 20px 0;	background: #5a0533;    border-top: 2px solid black;}
    footer ul{	padding-left: 0;	list-style-type: square;}
    a{
        color:white;
        text-decoration: none;
        font-family: 'Bitter';
    } 
    input{
        caret-color:red;
    }

    a:hover{
        color:white;
        text-decoration: none;
        font-family: 'Bitter';
        font-weight: bold;
    }
    /* Copy Right Footer */
    .footer-copyright {	background-color: #38021f;	padding: 5px 0;box-shadow: -1px -1px 3px black;border-top:1px solid black;}
    .footer-copyright .logo {    display: inherit;}
    .footer-copyright nav {    float: right;    margin-top: 5px;}
    .footer-copyright nav ul {	list-style: none;	margin: 0;	padding: 0;}
    .footer-copyright nav ul li {	border-left: 1px solid #505050;	display: inline-block;	line-height: 12px;	margin: 0;	padding: 0 8px;}
    .footer-copyright nav ul li a{	color: #969696;}
    .footer-copyright nav ul li:first-child {	border: medium none;	padding-left: 0;}
    .footer-copyright p {	color: #969696;	margin: 2px 0 0;}
    
    /* Footer Top */
    .footer-top{	background: #252525;	padding-bottom: 30px;	margin-bottom: 30px;	border-bottom: 3px solid #222;}
    
    /* Footer transparent */
    footer.transparent .footer-top, footer.transparent .main-footer{	background: transparent;}
    footer.transparent .footer-copyright{	background: none repeat scroll 0 0 rgba(0, 0, 0, 0.3) ;}
    
    /* Footer light */
    footer.light .footer-top{	background: #f9f9f9;}
    footer.light .main-footer{	background: #f9f9f9;}
    footer.light .footer-copyright{	background: none repeat scroll 0 0 rgba(255, 255, 255, 0.3) ;}
    
    /* Footer 4 */
    .footer- .logo {    display: inline-block;}
    
    /*==================== 
        Widgets 
    ====================== */
    .widget{	padding: 20px;	margin-bottom: 40px;}
    .widget.widget-last{	margin-bottom: 0px;}
    .widget.no-box{	padding: 0;	background-color: transparent;	margin-bottom: 40px;
        box-shadow: none; -webkit-box-shadow: none; -moz-box-shadow: none; -ms-box-shadow: none; -o-box-shadow: none;}
    .widget.subscribe p{	margin-bottom: 18px;color : #D0D3D4;} 
    .widget ul li{color : white;}
    .widget li a{	color: white;}
    .widget li a:hover{	color: #f8bbd0;text-decoration: none;}
    .widget-title {margin-bottom: 20px;font-size:25px;}
    .widget-title span {background: #839FAD none repeat scroll 0 0;display: block; height: 1px;margin-top: 25px;position: relative;width: 20%;}
    .widget-title span::after {background: inherit;content: "";height: inherit;    position: absolute;top: -4px;width: 50%;}
    .widget-title.text-center span,.widget-title.text-center span::after {margin-left: auto;margin-right:auto;left: 0;right: 0;}
    .widget .badge{	float: right;	background: #7f7f7f;}
    
    .typo-light h1, 
    .typo-light h2, 
    .typo-light h3, 
    .typo-light h4, 
    .typo-light h5, 
    .typo-light h6,
    .typo-light p,
    .typo-light div,
    .typo-light span,
    .typo-light small{	color:white;font-family: 'PT serif';}
    
    .typo-light h5{
        color:silver;
    }

    ul.social-footer2 {	margin: 0;padding: 0; width: auto;}
    ul.social-footer2 li {display: inline-block;padding: 0;}
    ul.social-footer2 li a:hover {background-color:#ad1457;border-radius:5px;align-items:center;}
    ul.social-footer2 li a {display: block;	height:30px;color:#ad1457;width: 30px;text-align: center;}
    .btn{background-color: #0a6e0f; color:rgb(233, 227, 227);border-radius:3px;}
    .btn:hover, .btn:focus, .btn.active {background: #155209;color: #fff;
    -webkit-box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    -ms-box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    -o-box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    -webkit-transition: all 250ms ease-in-out 0s;
    -moz-transition: all 250ms ease-in-out 0s;
    -ms-transition: all 250ms ease-in-out 0s;
    -o-transition: all 250ms ease-in-out 0s;
    transition: all 250ms ease-in-out 0s;
    }

     
    
</style>
</head>
<body>
<br />
<footer style = "font-size : 18px;" id="footer" class="footer-1">
    <div class="main-footer widgets-dark typo-light">
    <div class="container">
    <div class="row">
      
    <div class="col-xs-12 col-sm-6 col-md-3">
    <div class="widget subscribe no-box">
    <h2 class="widget-title mylink" style = "font-family:Acme;"><b><a href = "http://gecm.in/">GECM</a></b></h2>
    <p style="color:#fff;"><i class="fa fa-map-marker-alt" aria-hidden="true" style = "font-size:15px;color:#fff;"></i>  Address:
    Government Engineering College
     Mosalehosahalli,
    Hassan - 573 212
    Karnataka, India.</p>
    </div>
    </div>
    
    <div class="col-xs-12 col-sm-6 col-md-3">
    <div class="widget no-box">
    <h5 class="widget-title"><b>Quick Links</b></h5>
    <ul class="thumbnail-widget" >
    <li>
    <div class="thumb-content"><a href="https://gecm.in/#about">About GECM</a></div>	
    </li>
    <li>
    <div class="thumb-content"><a href="https://gecm.in/dept.html">Departments</a></div>	
    </li>
    <li>
    <div class="thumb-content"><a href="https://gecm.in/welfare.html">Student Welfare</a></div>	
    </li>
    <li>
    <div class="thumb-content"><a href="https://gecm.in/lib.html">Library</a></div>	
    </li>
    </ul>
    </div>
    </div>
    
    <div class="col-xs-12 col-sm-6 col-md-3">
    <div class="widget no-box">
    <ul class"thumbnail-widget">
    <h5 class="widget-title"><b>University</b></h5>
    <li><a  href="https://vtu.ac.in/about-vtu/" target="_blank">About VTU</a></li>
    <li><a  href="https://results.vtu.ac.in/" target="_blank">Results</a></li>
    <li><a  href="https://vtu.ac.in/computer-science-engineering/" target="_blank">CSE Deparment</a></li>
    <li><a  href="https://vtu.ac.in/category/examination/" target="_blank">Exam Circulars & Notifications</a></li>
    <li><a  href="https://vtu.ac.in/wp-content/uploads/2021/10/details.pdf" target="_blank">Contanct</a></li>
    </ul>
    </div>
    </div>
    
    <div class="col-xs-12 col-sm-6 col-md-3">
    
    <div class="widget no-box">
    <h5 class="widget-title"><b>Contact Us</b></h5>
    
    <p style= "color : #D0D3D4;"><a href="mailto:ranga_hassan@rediffmail.com" title="glorythemes" style="color:orange;"><i class='far fa-envelope' style='font-size:14px'></i> ranga_hassan@rediffmail.com</a></p>
    <p><i class='fas fa-phone-square'></i> +91 9448941222</p>
    
    <ul class="social-footer2">
    
    
    
    </ul>
    </div>
    </div>
    
    </div>
    </div>
    </div>
      
    <div class="footer-copyright">
    <div class="container">
    <div class="row">
    <div class="col-md-12 text-center">
    <p style = "font-family:'PT serif';color:white;">© Copyright 2024, All Rights Reserved.</p>
    </div>
    </div>
    </div>
    </div>
    </footer>
    </body>
    </html>