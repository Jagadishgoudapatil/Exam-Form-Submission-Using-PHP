<?php
require_once('../connection.php');
$user = $_SESSION['user']; // Make sure $user is defined (e.g., from a login session)
$query1 = "SELECT * FROM sub_reg where usn = '$user'";
$result = mysqli_query($con, $query1);
$rr = mysqli_num_rows($result);
if (!$rr) {
    echo "<h2 style='color:red;color:#ff0000;font-family:Acme;'>You have Not Registered For Exam Yet.!</h2>";
} else {

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admission Ticket</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous" />

        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css" />
        <script src="~/scripts/jquery-1.10.2.js"></script>

        <!-- #region datatables files -->
        <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" />
        <script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
        <!-- #endregion -->
        <link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet" />
    </head>
    <style type="text/css">
        .mh1 {
            font-family: 'Bitter';
            margin-top: 2%;
            margin-bottom: 5%;
            font-size: 40px;
            margin-bottom: auto;
            text-decoration: underline;
            text-decoration-color: rgb(2, 66, 85);
            text-decoration-style: dashed;
            text-align: center;
            text-shadow: 1px 1px 2px rgba(252, 164, 133, 0.6);
        }
        #print-area { /* Style the printable area */
            border: 1px solid #ccc;
            padding: 20px;  /* Add some padding */
        }

        @media print {
            body * {  /* Hide everything except the print area when printing */
                visibility: hidden;
            }
            #print-area, #print-area * {
                visibility: visible;
            }
            #print-area {
                position: absolute;
                left: 0;
                top: 0;
            }
            #printButton { /* Hide the print button itself when printing */
                visibility: hidden;
            }
            @page {
            size: landscape;  /* Set page orientation to landscape */
            }
            #print-area{
            width: auto;   /* Allow print area to take page width */
            margin: 0;        /* No margins */
            }
            body {          /* Set larger width for landscape */
                width: 11in; /* US Letter landscape width */
                height: 8.5in; /* US Letter landscape height */
            }
        }

    </style>

    <body>
        <h1 class="mh1">Subjects Registered</h1>
        <div class="container" style="margin-top: 5%;">
        <div id="print-area">    
        <div id="user-info">  <!--- Section for displaying user details -->
        <?php
            $user_query = "SELECT * FROM registration WHERE usn = '$user'";
            $user_result = mysqli_query($con, $user_query);
            $user_data = mysqli_fetch_assoc($user_result);

            //Now display the user details where needed in the hall ticket
            echo '<div style="display: flex; align-items: center; justify-content: center;">';
            echo '<div style="text-align: center; flex-grow: 1;">'; // Allows text to center and image to float right
            echo '<h1>VISVESVARAYA TECHNOLOGICAL UNIVERSITY,BELAGAVI</h1>';
            echo '<h2>Government Engineering College Mosalehosahalli-573212</h2>';
            echo '</div>';
            echo '<div style="margin-left:50px;"><img src="../images/' . $_SESSION['user'] . '/' . $user_data['image'] . '" width="100" height="100" alt="not found" /></div>';
            echo '</div>';
           
            echo "<center><h3>Admission Ticket for Examination</h3></center>";
            echo "<p><strong>Name:</strong> " . $user_data['fname'] . " " . $user_data['lname'] . "</p>";
            echo "<p><strong>USN:</strong> " . $user_data['usn'] . "</p>";
            echo "<p><strong>Semester:</strong> " . $user_data['sem'] . "</p>";
            


            // Add other relevant details here
        ?>
        </div>
            <table id="example" class="table responsive table-striped table-bordered table-hover">
                <thead>
                    <tr class="center" style="color:black;font-size:22px;text-align:center;font-family: 'PT serif';">
                        <th>Sl No.</th>
                        <th>Subject Name</th>
                        <th>Subject Code</th>
                        <th>Credits</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                while ($row = mysqli_fetch_array($result)) {
                    echo "<tr style=text-align:center;font-family:Bitter;font-size: 18px;>";
                    echo "<td>" . $i . "</td>";
                    echo "<td>" . $row['sub_name'] . "</td>";
                    echo "<td>" . $row['sub_code'] . "</td>";
                    echo "<td>" . $row['credits'] . "</td>";
                    echo "</tr>";
                    $i++;
                }

                ?>
                </tbody>

            </table>
            <P><h2><B>Intsructions For the Candidates</B></h2></p>
            <p><h3>1.Candidate should appear for examination cetre before 30 minutes of the examination timings.</h3></p>
            <p><h3>2.Please obtain signature of the principal of your examination centre.</h3></p>
            <p><h3>3.No electronic devices are allowed for the examination hall.For example smart phone,smart wathes etc.</h3></p>
            <p><h3>4.Student should compulsary write their usn on the question paper. No other things should be written in the question paper.</h3></p>
            <p><h3>5.Only black ball point pen is allowed for writing the exam.</h3></p>




        </div> 



<button id="printButton" onclick="printHallTicket()">Print Hall Ticket</button> 


<script>
   function printHallTicket() {
      window.print();
    }
</script>
<!-- ... (Existing script includes) ... -->

<?php
  } // Close the else block
?>

    </body>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#example").DataTable();
        });
    </script>

    </html>