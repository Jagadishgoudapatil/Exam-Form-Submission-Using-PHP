<?php
// Include your database connection
require_once('connection.php');

// Start session to access student details and restrict access to logged-in users
session_start();
if (!isset($_SESSION['student_name']) || !isset($_SESSION['usn'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit;
}

$student_name = $_SESSION['student_name'];
$usn = $_SESSION['usn'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['semester']) && isset($_POST['subjects'])) {
    $semester = $_POST['semester'];
    $selected_subjects = $_POST['subjects'];
    
    foreach ($selected_subjects as $subject_code) {
        // Check if the subject is already registered
        $checkQuery = "SELECT * FROM registered_subjects WHERE usn = '$usn' AND subject_code = '$subject_code' AND semester = '$semester'";
        $checkResult = mysqli_query($con, $checkQuery);
        
        if (mysqli_num_rows($checkResult) == 0) {
            // Insert selected subjects if not already registered
            $query = "INSERT INTO registered_subjects (usn, subject_code, semester) VALUES ('$usn', '$subject_code', '$semester')";
            mysqli_query($con, $query);
            $message = "<p style='color:green;'>Subjects registered successfully for Semester $semester!</p>";
        } else {
            $message = "<p style='color:red;'>Some subjects were already registered for Semester $semester.</p>";
        }
    }
}

// Retrieve selected semester from form submission or default to 1st semester
$selected_semester = $_POST['semester'] ?? 1;

// Fetch subjects based on selected semester
$query = "SELECT subject_name, subject_code, credits FROM subjects WHERE semester = $selected_semester";
$result = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register for Exam</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; color: #333; }
        .container { max-width: 800px; margin: auto; padding: 20px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); text-align: center; }
        h2 { color: #d81b60; } /* Dark pink header */
        .semester-select { font-size: 16px; padding: 5px; margin: 10px 0; }
        .subject-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .subject-table th, .subject-table td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        .subject-table th { background-color: #d81b60; color: white; } /* Dark pink table header */
        .btn { padding: 10px 20px; font-size: 16px; cursor: pointer; border-radius: 5px; margin: 10px; }
        .submit-btn { background-color: #4CAF50; color: white; border: none; }
        .reset-btn { background-color: #777; color: white; border: none; }
        .message { margin: 20px 0; }
    </style>
</head>
<body>

<div class="container">
    <h2>Register for Exam</h2>
    <p>Welcome, <?php echo htmlspecialchars($student_name); ?></p>

    <!-- Display message if subjects were registered successfully -->
    <?php if (!empty($message)): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <!-- Semester Selection Form -->
    <form method="POST" action="register.php">
        <label for="semester">Select Semester:</label>
        <select name="semester" id="semester" class="semester-select" onchange="this.form.submit()">
            <?php
            // Generate options for all 8 semesters
            for ($i = 1; $i <= 8; $i++) {
                echo "<option value='$i'" . ($i == $selected_semester ? " selected" : "") . ">Semester $i</option>";
            }
            ?>
        </select>
    </form>

    <!-- Subjects Table (re-rendered based on semester selection) -->
    <form method="POST" action="register.php">
        <input type="hidden" name="semester" value="<?php echo $selected_semester; ?>">
        <table class="subject-table">
            <tr>
                <th>Select</th>
                <th>Subject Name</th>
                <th>Subject Code</th>
                <th>Credits</th>
            </tr>
            
            <?php
            // Display subjects for the selected semester
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td><input type='checkbox' name='subjects[]' value='" . $row['subject_code'] . "'></td>";
                echo "<td>" . htmlspecialchars($row['subject_name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['subject_code']) . "</td>";
                echo "<td>" . htmlspecialchars($row['credits']) . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
        <br>
        <button type="submit" class="btn submit-btn">Submit</button>
        <button type="reset" class="btn reset-btn">Reset</button>
    </form>
</div>

</body>
</html>
