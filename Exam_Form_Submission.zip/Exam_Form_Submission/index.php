<?php
// Include the database connection file
require_once('connection.php');
session_start();

if (isset($_POST['Login'])) {
    // Retrieve the input values
    $usn = $_POST['usn'] ?? '';
    $Password = $_POST['Password'] ?? '';

    // Check if the fields are not empty
    if ($usn == "" || $Password == "") {
        $err = "<font color='red' align='center'>Enter a Valid USN & Password</font>";
    } else {
        // Sanitize and hash the password
        $usn = mysqli_real_escape_string($con, strtoupper(trim($usn))); // Ensure USN is in uppercase
        $Password = mysqli_real_escape_string($con, $Password);
        $pass = md5($Password); // MD5 hash the password

        // Use prepared statements to prevent SQL injection
        $stmt = $con->prepare("SELECT * FROM `registration` WHERE usn=? AND password=?");
        $stmt->bind_param("ss", $usn, $pass); // Bind parameters
        $stmt->execute(); // Execute the statement
        $result = $stmt->get_result(); // Get the result set
        $r1 = $result->num_rows; // Check number of rows returned

        // If a matching record is found, set the session and redirect
        if ($r1) {
            $_SESSION['user'] = $usn;
            header('location:user/dashboard.php');
        } else {
            $err = "<font color='red'>Invalid login details</font>";
        }
        $stmt->close(); // Close the statement
    }
}
?>

<!-- index.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- Bootstrap and Fontawesome CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">

    <!-- Custom styles -->
    <link rel="stylesheet" type="text/css" href="css/styles.css">

    <!-- Custom Favicon -->
    <link rel="icon" type="image/png" sizes="64x64" href="../css/images/logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Inline CSS for demonstration -->
    <style type=text/css>
        @import url('https://fonts.googleapis.com/css?family=Acme|Bree+Serif|Patrick+Hand|Volkhov|Handlee|PT+Serif|Numans|Bitter|Odibee+Sans|Simonetta|Trade+Winds&display=swap');
        .back-to-top { position: fixed; bottom: 25px; right: 25px; display: none; }
        .container { top: 0; margin-top: 0; padding-top: 0; }
        input { caret-color: red; }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark static-top" style="background-color: #5a0533; border-bottom: 1px solid black; box-shadow: 3px 3px 5px;">
        <div class="container" style="font-family: 'PT Serif'; font-size: 22px; padding-right: 0px; margin-right: 0%;">
            <a class="navbar-brand" href="http://gecm.in">
                    <span class="mh3">GECM</span><br />
                    <p style="margin-left: 6%; font-size: 12px; margin-top: 0; position: absolute; top: 60px"><br /></p>
                </h3>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse mnav" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#"><i class="fa fa-key" aria-hidden="true"></i> Login
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php"><i class="fa fa-user-plus" aria-hidden="true"></i> Register</a>
                    </li>
                    <li class="nav-item">
                            <a class="nav-link" href="fst_register.php"><i class="fa fa-user-plus" aria-hidden="true"></i>Fastrack Register</a>
                        </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin/index.php"><i class="fa fa-lock" aria-hidden="true"></i> Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="help.php"><i class="fa fa-question" aria-hidden="true"></i> Help</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php"><i class="fa fa-info-circle" aria-hidden="true"></i> About</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Login Form Container -->
    <div class="container">
        <div class="d-flex justify-content-center h-100">
            <div class="card mcon" id="card">
                <div class="card-header" id="card-header">
                    <h3 align="center" style="color:#000">Sign - In</h3>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <p align='center'><b><?php echo @$err; ?></b></p> 
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" autocapitalize="characters" autocomplete="off" class="form-control a" name="usn" placeholder="USN">
                        </div> 
                    
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input type="password" class="form-control" name="Password" placeholder="Password">
                        </div>
                        <div class="row justify-content-center">
                            <div class="row">
                                <div class="col-sm-12">
                                    <input type="submit" value="Login" style="color:white" name="Login" class="login_btn">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-footer" id="card-footer">
                    <div class="d-flex justify-content-center">
                        <a href="register.php" style="text-decoration:none; color:black;">New User? Register Here</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Back to top button -->
    <a id="back-to-top" data-toggle="tooltip" data-placement="auto" title="Back-to-Top" style="color:#000; background-color:#fff; border:2px solid black;" href="#" class="btn-light btn-lg back-to-top hidden-mobile" role="button"><i class="fas fa-arrow-up"></i></a>

    <!-- Footer -->
    <footer class="bg-dark text-white mt-5">
        <div class="container text-center">
            <p>&copy; 2024 GECM. All Rights Reserved.</p>
            <p><a href="about.php" class="text-white">About Us</a> | <a href="help.php" class="text-white">Help</a></p>
        </div>
    </footer>
    
    <!-- Include the footer -->
    <?php require_once('footer.php'); ?>
</body>
</html>
